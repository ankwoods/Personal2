$xlXMLSpreadsheet = 56

$Excel = New-Object -Com Excel.Application

$WorkBook = $Excel.Workbooks.Open($strFilePath)

$WorkBook.SaveAs($strFinalPath, $xlXMLSpreadsheet)

$Excel.Quit()