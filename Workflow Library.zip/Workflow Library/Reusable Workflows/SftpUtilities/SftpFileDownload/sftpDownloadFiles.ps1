<#Input parameters from UiPath in PowerShellVariables property
# $sftpRemotePath = remote path on FTP server
# $filePattern = REGEX pattern used to filter files
# $localDownloadPath = path to download files from FTP server to
# $downloadFileList = CSV of files transferred (full file path)
# $sftpHostName = address of FTP server
# $sftpPortNumber = port of FTP server (int)
# $sftpUserName = user name for FTP server
# $sftpPassword = password for FTP server (required if using password authentication)
# $sftpPrivateKeyName = path to private key file (PuTTY format key .ppk) (required if using public key authentication)
# $sftpPrivateKeyPassphrase = password used for private key (optional, only supplied if private key has a password)
# $sftpHostKeyFingerprint = ssh fingerprint of FTP server
# $scriptPath = location of DLL and EXE for WinSCP
# $sftpFileDownloadLimit = maximum number of files to download (optional), enter a value less than or equal to 0 for no limit
# $useUtfFilenameEncoding = string to use UTF-8 filename encoding if server supports it: false = off, true = on
# $sftpMaxConnections = maximum number of connections to use concurrently
#>
$statusCode = New-Object System.String("-1")
[int32]$fileCount = 0
[bool]$useUtfFilenames = $false
[int32]$maxTaskCount = 10
[bool]$usePrivateKeyAuth = $false

##check input parameters for null or empty strings
if ([string]::IsNullOrWhiteSpace($localDownloadPath)) { return "Empty localDownloadPath parameter" }
#if filePattern is not provided, then default to all files
if ([string]::IsNullOrWhiteSpace($filePattern)) {
	$filePattern = New-Object System.String(".*")
}
if ([string]::IsNullOrWhiteSpace($sftpRemotePath)) { return "Empty sftpRemotePath parameter" }
if ([string]::IsNullOrWhiteSpace($downloadFileList)) { return "Empty downloadFileList parameter" }
if ([string]::IsNullOrWhiteSpace($sftpHostName)) { return "Empty sftpHostName parameter" }
if ([string]::IsNullOrWhiteSpace($sftpUserName)) { return "Empty sftpUserName parameter" }
if ([string]::IsNullOrWhiteSpace($sftpHostKeyFingerprint)) { return "Empty sftpHostKeyFingerprint parameter" }
if ([string]::IsNullOrWhiteSpace($scriptPath)) { return "Empty scriptPath parameter" }
if (![Int32]$sftpPortNumber) { return "sftpPortNumber cannot be null" }
if ((![Int32]$sftpFileDownloadLimit) -Or ($sftpFileDownloadLimit -le 0)) { $hasDownloadLimit = $false  } else { $hasDownloadLimit = $true }
if ([string]::IsNullOrWhiteSpace($useUtfFilenameEncoding)) {
	return "useUtfFilenameEncoding parameter is null"
} else {
	try {
		$useUtfFilenames = [System.Convert]::ToBoolean($useUtfFilenameEncoding)
	} catch {
		return ("Invalid useUtfFilenameEncoding parameter value: " + $useUtfFilenameEncoding + ". Must be true or false")
	}
}
#set max connections, default to 10 if value supplied is less than 0 or greater than 10
if (!($sftpMaxConnections -le 0) -And !($sftpMaxConnections -gt $maxTaskCount)) { $maxTaskCount = $sftpMaxConnections }

#check for authentication method, either password based or private key, private key takes precedence if both are supplied
if ([string]::IsNullOrWhiteSpace($sftpPassword) -And [string]::IsNullOrWhiteSpace($sftpPrivateKeyName)) {
	return ("At least one authentication method sftpPassword or sftpPrivateKeyName must be entered")
} elseif (!([string]::IsNullOrWhiteSpace($sftpPrivateKeyName))) {
	$sftpSshPrivateKeyPath = ([System.IO.Path]::Combine($scriptPath, $sftpPrivateKeyName))
	$usePrivateKeyAuth = $true
	#check for blank sftpPrivateKeyPassphrase
	if ([string]::IsNullOrWhiteSpace($sftpPrivateKeyPassphrase)) {
		$sftpPassword = New-Object -TypeName System.String("")
	} else {
		$sftpPassword = $sftpPrivateKeyPassphrase
	}
}

try {
	# Load WinSCP .NET assembly
	Add-Type -Path ([System.IO.Path]::Combine($scriptPath, "WinSCPnet.dll"))

	# Set up session options
	if ($usePrivateKeyAuth) {
		$sessionOptions = New-Object WinSCP.SessionOptions -Property @{
			Protocol = [WinSCP.Protocol]::Sftp
			HostName = $sftpHostName
			PortNumber = $sftpPortNumber
			UserName = $sftpUserName
			SshPrivateKeyPath = $sftpSshPrivateKeyPath
			PrivateKeyPassphrase = $sftpPassword
			SshHostKeyFingerprint = $sftpHostKeyFingerprint
		}
	} else {
		$sessionOptions = New-Object WinSCP.SessionOptions -Property @{
			Protocol = [WinSCP.Protocol]::Sftp
			HostName = $sftpHostName
			PortNumber = $sftpPortNumber
			UserName = $sftpUserName
			Password = $sftpPassword
			SshHostKeyFingerprint = $sftpHostKeyFingerprint
		}
	}


	$sessionOptions.AddRawSettings("FSProtocol", "2")
	$sessionOptions.AddRawSettings("ResolveSymlinks", "0")
	if ($useUtfFilenames) {
		$sessionOptions.AddRawSettings("Utf","1")
	} else {
		$sessionOptions.AddRawSettings("Utf","0")
	}

	$session = New-Object WinSCP.Session
	$session.Timeout = New-Timespan -minutes 3
    $session.SessionLogPath = $null
    $session.DebugLogPath = $null

	try
	{
		# Connect
		$session.Open($sessionOptions)

		#test for output file and remove if it exists

		if (Test-Path $downloadFileList)
		{
			Remove-Item $downloadFileList
		}

		#Write downloadFileList header
		("`"localFileName`",`"remoteFileName`",`"modifiedDate`"") | Out-File -Append $downloadFileList -Encoding utf8

		#retrieve directory listing for sftpRemotePath
		$directoryListing = $session.ListDirectory($sftpRemotePath)

		#Get list of files matching pattern and not a directory. If a file limit is present, sort by LastWriteTime property (asc) and select only the number of files requested.
        if ($hasDownloadLimit) {
		    [array]$filteredFiles = ($directoryListing.Files | Where-Object {-Not $_.IsDirectory} | Where-Object {$_.Name -Match $filePattern} | Sort-Object -Property {$_.LastWriteTime} | Select-Object -First $sftpFileDownloadLimit)
		} else {
            [array]$filteredFiles = ($directoryListing.Files | Where-Object {-Not $_.IsDirectory} | Where-Object {$_.Name -Match $filePattern})
        }
        #Check for matching files
		If ($filteredFiles -ne $null -Or $filteredFiles.Count -gt 0) {
            #set batch limit based on number of files found and max task count
            $batchLimit = ($filteredFiles.Count / $maxTaskCount)

            $fileIndexStart = 0
            $taskNum = 0
            $batchTotal = 0

            for ($i = 0; $i -lt $filteredFiles.Count; $i++) {
                 if(($taskNum + 1) -gt $maxTaskCount) {
                    throw("Task count $($taskNum) exceeds max task limit of $($maxTaskCount)")
                 }
                 $batchTotal++
                 if (($batchTotal -ge $batchLimit) -or ($i -eq $filteredFiles.Count - 1)) {

                    $fileList = $filteredFiles[$fileIndexStart..$i]

                    #Create transfer job and start
                    Start-Job -Name "FtpTransferTask $taskNum" `
                        -ArgumentList $sftpHostName, $scriptPath, $sftpRemotePath, $localDownloadPath, $taskNum, $fileList, $sftpPortNumber, $sftpUserName, $sftpPassword, $sftpHostKeyFingerprint, $useUtfFilenames, $usePrivateKeyAuth, $sftpSshPrivateKeyPath {

                        param (
                        [Parameter(Position = 0)]
                        $sftpHostName,
                        [Parameter(Position = 1)]
                        $scriptPath,
                        [Parameter(Position = 2)]
                        $sftpRemotePath,
                        [Parameter(Position = 3)]
                        $localDownloadPath,
                        [Parameter(Position = 4)]
                        $taskNum,
                        [Parameter(Position = 5)]
                        $fileList,
                        [Parameter(Position = 6)]
                        $sftpPortNumber,
                        [Parameter(Position = 7)]
                        $sftpUserName,
                        [Parameter(Position = 8)]
                        $sftpPassword,
                        [Parameter(Position = 9)]
                        $sftpHostKeyFingerprint,
                        [Parameter(Position = 10)]
                        $useUtfFilenames,
						[Parameter(Position = 11)]
						$usePrivateKeyAuth,
						[Parameter(Position = 12)]
						$sftpSshPrivateKeyPath
                        )
                        [int32]$taskFileCount = 0
                        $taskOutputList = New-Object -TypeName System.Collections.ArrayList
                        $taskStatusCode = New-Object -TypeName System.String("")
                        $statusMessage = New-Object -TypeName System.String("")
                        $taskResults = New-Object -TypeName 'System.Collections.Generic.Dictionary[System.String, System.Object]'
                        $taskResults.Add("taskNum", $taskNum)
                        try
                        {

                            Add-Type -Path ([System.IO.Path]::Combine($scriptPath, "WinSCPnet.dll"))
                            # Set up session options
							if ($usePrivateKeyAuth) {
								$taskSessionOptions = New-Object WinSCP.SessionOptions -Property @{
									Protocol = [WinSCP.Protocol]::Sftp
									HostName = $sftpHostName
									PortNumber = $sftpPortNumber
									UserName = $sftpUserName
									SshPrivateKeyPath = $sftpSshPrivateKeyPath
									PrivateKeyPassphrase = $sftpPassword
									SshHostKeyFingerprint = $sftpHostKeyFingerprint
								}
							} else {
								$taskSessionOptions = New-Object WinSCP.SessionOptions -Property @{
									Protocol = [WinSCP.Protocol]::Sftp
									HostName = $sftpHostName
									PortNumber = $sftpPortNumber
									UserName = $sftpUserName
									Password = $sftpPassword
									SshHostKeyFingerprint = $sftpHostKeyFingerprint
								}
							}

                            $taskSessionOptions.AddRawSettings("FSProtocol", "2")
                            $taskSessionOptions.AddRawSettings("ResolveSymlinks", "0")
                            if ($useUtfFilenames) {
                               $taskSessionOptions.AddRawSettings("Utf","1")
                            } else {
                               $taskSessionOptions.AddRawSettings("Utf","0")
                            }

                            try
                            {
                                $taskSession = New-Object WinSCP.Session
                                $taskSession.Timeout = New-Timespan -minutes 3
                                $taskSession.SessionLogPath = $null
                                $taskSession.DebugLogPath = $null

                                $taskSession.Open($taskSessionOptions)

                                foreach ($fileInfo in $fileList) {
                                    $transferResult = $taskSession.GetFiles([WinSCP.RemotePath]::EscapeFileMask($fileInfo.FullName), $localDownloadPath)
                                    if ($transferResult.IsSuccess) {
                                        $modifiedDateString = ([DateTime]$fileInfo.LastWriteTime).ToString("s")
                                       	[void]$taskOutputList.Add(("`"{0}`",`"{1}`",`"{2}`"" -f ($localDownloadPath + $fileInfo.Name), $fileInfo.Name, $modifiedDateString))
                                       $taskFileCount++
                                    }
                                }
                                $taskStatusCode = "SUCCESS"
                                $statusMessage = "SUCCESS"
                            }
                            finally
                            {
                                $taskSession.Dispose()
                            }
                        }
                        catch
                        {
                            $taskStatusCode = "FAILED"
                            $statusMessage = "$($_.Exception.Message)"
                        }
                        finally {
                            $taskResults.Add("outputList", $taskOutputList)
                            $taskResults.Add("fileCount", $taskFileCount)
                            $taskResults.Add("status", $taskStatusCode)
                            $taskResults.Add("statusMessage", $statusMessage)
                        }
                        Write-Output $taskResults
                        exit 0

                    } | Out-Null

                    # Reset for the next batch
                    $taskNum++
                    $batchTotal = 0
                    $fileIndexStart = $i + 1
                 }

            }

            #Wait for all tasks to finish and retrieve results from each task
            [array]$resultList = Get-Job | Wait-Job | Receive-Job


            #Parse and validate task results
            if ($resultList -ne $null -and $resultList.Count -gt 0) {
                $resultCounter = 0
                foreach($result in $resultList) {
                    if($result.ContainsKey("status") -and $result.ContainsKey("outputList") -and $result.ContainsKey("fileCount") -and $result.ContainsKey("statusMessage") -and $result.ContainsKey("taskNum")) {
                        if($result.Item("status") -eq "SUCCESS" ) {
                            if ($result.Item("fileCount") -le 0) { break }
                            $fileCount = $fileCount + $result.Item("fileCount")
                            #add row to downloadFileList
							foreach($outputItem in $result.Item("outputList")) {
                               $outputItem | Out-File -Append $downloadFileList -Encoding utf8
                            }

                        } else {
                            throw ("Transfer task $($result.Item("taskNum")) failed with message: $($result.Item("statusMessage"))")
                        }
                    } else {
                        throw("Missing one or more values in result set $($resultCounter) of $($resultList.Count)")
                    }
                    $resultCounter++
                }
            } else {
                throw("No results returned from $($taskNum) transfer tasks")
            }

			$statusCode = "Success"
		} Else {
			$statusCode = "No_Files_Matched"
		}

	}
	catch {
        Get-Job | Stop-Job | Out-Null
		$statusCode = "Error: $($_.Exception.Message)"
	}
	finally
	{
		$session.Dispose()
	}

	return $statusCode
}
catch {
	$statusCode = "Error: $($_.Exception.Message)"
	return $statusCode
}
