﻿$servers = @{
    SANDBOX="http://vdcawd05204.logon.ds.ge.com";
    DEV="https://vdcawd04166.logon.ds.ge.com";
    PROD="https://cihctspweba488c.logon.ds.ge.com"
}
$credentialFile = "$env:USERPROFILE\Documents\WindowsPowerShell\.orch_credentials"
$auth = $null
$lastAuth = $null
$orchestratorCred = $null
$tokenTimeoutMinutes = 30
$loginTenancy = "default"
$environment = "DEV"



#Module commands

#Prompts for a username and password and creates the credential file
function Set-OrchCredentials() {
    $cred = Get-Credential -Message "Enter your Orchestrator username and password." -UserName $env:USERNAME
    $credJson = ConvertTo-Json @{
        username = $cred.UserName;
        password = ConvertFrom-SecureString $cred.Password
    }
    $credJson | Out-File $credentialFile
    return $cred
}


#Delete the credential file and prompt the user to login again
function Reset-Credentials() {
    rm $credentialFile
    $script:orchestratorCred = Set-OrchCredentials
    Get-OrchestratorAuthToken
}

#Changes the environment and logs in again
function Switch-Environment($tenancy="default", $environment="DEV") {
    $script:loginTenancy = $tenancy
    $script:environment = $environment.ToUpper()
    Get-OrchestratorAuthToken
}

function Get-Environment() {
    return [PSCustomObject]@{
        Environment=$environment;
        Tenancy=$loginTenancy
    }
}

#Authenticate to Orchestrator
function Get-OrchestratorAuthToken() {
    Write-Host "Logging into Orchestrator (Environment: $environment/$loginTenancy)"
    $authParams = ConvertTo-Json @{
        tenancyName = $loginTenancy;
        usernameOrEmailAddress = $orchestratorCred.UserName;
        password = $orchestratorCred.GetNetworkCredential().Password
    }
    $server = $servers[$environment]
    $req = Invoke-WebRequest -Method Post -Uri "$server/api/account/authenticate" -Body $authParams -ContentType "application/json" | ConvertFrom-Json
    
    $script:auth = @{
        Authorization= "Bearer $($req.result)"
    }
    $script:lastAuth = Get-Date
}

#Invokes an Odata web request
function Invoke-OdataRequest($ObjName, $Filter, $Id, $MethodName, $HttpMethod="Get", $Body) {
    if($auth -eq $null -or (Get-Date) - $lastAuth -gt [System.TimeSpan]::FromMinutes($tokenTimeoutMinutes)) {
        Get-OrchestratorAuthToken
    }

    $server = $servers[$environment]
    $requestString = "$server/odata/$ObjName"

    if($Id -ne $null) {
        $requestString = "$requestString($Id)/$MethodName"
    } elseif($filter -ne $null) {
        $requestString = "$requestString`?`$filter=$Filter"
    } elseif($MethodName -ne $null) {
        $requestString = "$requestString/$MethodName"
    }

    $response = Invoke-WebRequest $requestString -Headers $auth -Method $HttpMethod -Body $(ConvertTo-Json -Compress $Body) -ContentType "application/json"
    if($response.StatusCode -ne 200) {
        throw "Request returned status code $($response.StatusCode)"
    }

    if ($response.Content -is [String]) {
        return (ConvertFrom-Json $response.Content).value
    } else {
        return ""
    }
}

#Get an asset by name
function Get-Asset($Name) {
    $result = Invoke-OdataRequest "Assets" -Filter "Name eq '$Name'"
    return $result | Select-Object -Property Id, Name, ValueType, Value
}


#Sets the asset to the given value
function Set-Asset($Name, $Value) {
    $asset = Get-Asset $name
    $updateObj = @{
        Id = $asset.Id;
        Name = $Name;
        ValueScope = "Global";
        ValueType = $asset.ValueType
    }
    switch ($asset.ValueType) {
        "Text" {  $updateObj.StringValue = $Value }
        "Bool" { $updateObj.BoolValue = [bool]::Parse($Value) }
        "Integer" { $updateObj.IntValue = [int]::Parse($Value) }
        default { throw "Value type not supported" }
    }
    
    ConvertTo-Json -Compress $updateObj | echo
    $result = Invoke-OdataRequest -ObjName Assets -Id $asset.Id -HttpMethod Put -Body $updateObj
    return [PSCustomObject]@{
        Name = $Name;
        AssetId = $asset.Id;
        PreviousValue = $asset.Value;
        NewValue = $Value
    }
}

#Updates the given robot to the most recently deployed package
function Update-Release($ProcessName) {
    echo "Retrieving release"
    $currentRelease = Get-Release $ProcessName
    $releaseId = $currentRelease.Id
    echo "Updating release"
    $result = Invoke-OdataRequest -ObjName "Releases" -Id $releaseId -MethodName UiPath.Server.Configuration.OData.UpdateToLatestPackageVersion -HttpMethod Post
    echo "Getting newest version"
    $newestVersion = (Get-Release $ProcessName).ProcessVersion
    echo "$ProcessName updated from $($currentRelease.ProcessVersion) to $newestVersion in $environment/$loginTenancy"
}

#Gets the Release object associated with the given robot
function Get-Release($ProcessName) {
    return Invoke-OdataRequest -ObjName Releases -Filter "ProcessKey eq '$ProcessName'"
}


#Trigger a robot via Orchestrator or Skynet
function Start-Robot($ProcessName, [switch]$Skynet) {
    if($Skynet) {
        $outlookRef = New-Object -com Outlook.Application
        $mail = $outlookRef.CreateItem(0)
        $mail.subject = "RUN $ProcessName"
        $mail.To = 'RPA.DigitalDevMHub@ge.com'
        $mail.Send()
        echo "RUN $ProcessName command sent to Skynet"
    } else {
        $releaseKey = (Get-Release $ProcessName).Key
        $startJobsObject = @{
            startInfo=@{
                ReleaseKey = $releaseKey;
                RobotIds = @();
                NoOfRobots = 1;
                Strategy = "RobotCount"
            }
        }

        Invoke-OdataRequest -ObjName Jobs -MethodName "UiPath.Server.Configuration.OData.StartJobs" -HttpMethod Post -Body $startJobsObject
    }
}

#Open a Kibana log for the given bot in the default browser
function Open-Kibana($ProcessName, [switch]$Dev, [switch]$ECDev, [switch]$EC) {
    #Default parameters (Prod, Default index)
    $kibanaServer = "cihctspappa507c.logon.ds.ge.com"
    $windowsAccount = "lg662085sv"
    $index = "default*"

    if($Dev) {
        $kibanaServer = "vdcawd04166.logon.ds.ge.com"
        $windowsAccount = "lg717951sv"
    } elseif($ECDev) {
        $kibanaServer = "vdcawd04166.logon.ds.ge.com"
        $index = "dev-*"
    } elseif($EC) {
        $index = "prod-ec-*"
        $windowsAccount = "lg743182sv"
    }

    

    Start-Process "http://$kibanaServer`:5601/app/kibana#/discover?_g=(refreshInterval:(display:'10%20seconds',pause:!f,section:1,value:10000),time:(from:now%2Fd,mode:quick,to:now%2Fd))&_a=(columns:!(level,message),filters:!(),index:'$index',interval:auto,query:(query_string:(analyze_wildcard:!t,query:'(processName:%20$ProcessName*)%20AND%20windowsIdentity:*$windowsAccount*')),sort:!('@timestamp',desc),vis:(aggs:!((params:(field:level,orderBy:'2',size:20),schema:segment,type:terms),(id:'2',schema:metric,type:count)),type:histogram))&indexPattern=default*&type=histogram"

}

#Module init (Should be at the bottom)

#Read in credential, or prompt for password if file does not exist

if (Test-Path $credentialFile) {
    $credFromJson = Get-Content $credentialFile | ConvertFrom-Json
    $orchestratorCred = New-Object System.Management.Automation.PSCredential($credFromJson.username, ($credFromJson.password | ConvertTo-SecureString))
} else {
    $orchestratorCred = Set-OrchCredentials
}