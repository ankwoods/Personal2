Last Updated: 2/23/2017

Guidelines:

Select period module selects periods provided to the process in a string. 

Note: 
1. Periods must follow mmm_yy format.
2. String must be comma delimited.


