Last Updated: 3/5/2017

Guidelines:
***Only tested on Account ID but designed to work on other attributes. Please update additional attributes tested successfully. Reach out to Stan Chulsky 212443046 for any issues.
ARM Build Filter activity can be used to filter by text values via Advanced filter in reconciliation or profile list. 

Note: 
1. The process will automatically switch to Advanced filter each time it runs.
2. Process is transactional and adds one filter value at a time. 
3. strResults - return process results. Will show whether the filter input returned the value and was successfully added to the filter transaction.
4. strFilter_Value - Text value to be used to filter the list
5. strConjunction_Value - conjunction filter value must match ARM exactly. Conjunction cannot be used in value in the filter. 
6. strFilterAttribute - Attribute to filter by. Must match attribute available in ARM. The attribute must be visible in the list.
7. strOperand_Value - Operand will be defaulted to �contains� if not selected. String must match one of text values in ARM filter dropdown. 
8. bFirstValueInFilter - Boolean variable will reset the filter each time it is set to True and will avoid using conjunction as first value in the list does not permit conjunction values to be entred. 
9. ARM performance will deteriorate when number of values in filter exceed 20 items.
10. Ensure to use proper case, spacing and spelling in all drop down string inputs. 
