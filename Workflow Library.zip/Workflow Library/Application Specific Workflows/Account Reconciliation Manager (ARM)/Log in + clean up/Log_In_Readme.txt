Last Updated: 2/21/2017

Guidelines:

ARM Log in module is used to clean up environment by closing all relevant applications and log in to the tool. The process will automatically navigate to Reconciliation list following each log in sequence.

Note: 

1. Process provides Boolean inputs to control which processes are to be terminated to avoid conflicts. 

2. Process has an option to clear cache in IE. 

3. The activity is set up to retry up to 3 times if failed.

4. User name and password are SSO login credentials, which are required to have access for the activity to  work.

5. Email module is required to communicate errors.



Inputs

3. bARM_QA variable provides an option to point the activity to ARM stage environment. 

4. strAdmin DL uses email activity to send notifications in case of an issue. 



