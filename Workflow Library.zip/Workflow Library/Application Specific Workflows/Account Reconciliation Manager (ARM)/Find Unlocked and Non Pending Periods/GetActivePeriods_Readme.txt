Last Updated: 2/23/2017

Guidelines:

Get active period activity in ARM is used to retrieve up to 10 most recent active periods.

Note: 

1. Able to return no more than 10 periods in the data table.


