Last Updated: 2/26/2017

Descriptions:
Build a standard Oracle DB connection String to use in a connect to DB activity

Input:
Username:  String, DB Username.
Password:  SecureString, DB Password.
ServiceName:  String, Oracle Service Name.
Host:  String, Oracle DB Host.
Port:  String, Oracle Port Number.

Output:
DBString: The created output for an Oracle DB Connection

Notes: 
1.  Will need oracle client installed for these activities to function.
2.  Should not be logged as the password will be unmasked in the connection string at runtime.
