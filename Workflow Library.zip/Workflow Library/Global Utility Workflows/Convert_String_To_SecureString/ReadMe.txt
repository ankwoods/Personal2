Last Updated: 2/26/2017

Descriptions:
Convert any String to a SecureString type.

Input:
InputString:  Standard String being input to the workflow.

Output:
SecureString: SecureString that is created from the input.

Notes: 
NA