Last Updated: 6/26/2017

Descriptions:
compare 2 reports with given primary key.

Input:
dtLeft:  one of two the comparing data table.
dtRight: one of two the comparing data table.
primaryListRight: array of system.string e,g. {leftColumn1,leftColumn2}, primary key of Left data table.
primaryListLeft: array of system.string e,g. {rightColumn1,rightColumn2}, primary key of Right data table.

Output:
dtLeft:  with additional column to indicate if it is matched or not by primary key.
dtRight: with additional column to indicate if it is matched or not by primary key.

Notes: 
1.  this is a simple emulation of a database full outer join feature.