Last Updated: 2/26/2017

Descriptions:
Convert any string to Normalization Form (FormD) to remove special characters and accents etc.. (Ex: �� to O)

Input:
stringInput: String to be converted.

Output:
stringOutput: String that has been converted.

Notes: 
NA
