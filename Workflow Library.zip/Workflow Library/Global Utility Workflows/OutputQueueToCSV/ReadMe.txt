Last Updated: 2/26/2017

Descriptions:
Create a CSV file from any UiPath Queue to create an output of items in the Queue in CSV format.

Input:
QueueName: String of the name of the UiPath Queue.
OutputFile: String of the full path of the file to be created for Output.

Output:
NA

Notes: 
1. Final Report is structed just as it is in the queue.
2. Columns are named after queue Keys.
