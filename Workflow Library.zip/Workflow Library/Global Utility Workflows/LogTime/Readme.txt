LogTime.xaml

Logs a message with Info log level to Kibana with the totalExecutionTimeInSeconds field set to the
number of seconds between StartTime and the current time (i.e. DateTime.Now). Useful for creating dashboards
in Kibana based off an execution time.


**In Arguments**

*StartTime - DateTime - default DateTime.Now - The starting time used to calculate the total execution time.
*LogMessage - String - default "Time recorded" - The log message to display.

**In/Out Arguments**

N/A

**Out Arguments**

N/A

**Starting UI state**

N/A

**Ending UI state**

N/A

**Required Applications**

N/A

**Contact**

Brandon Dadosky (brandon.dadosky@ge.com)

