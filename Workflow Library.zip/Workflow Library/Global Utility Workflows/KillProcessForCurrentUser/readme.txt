KillProcessForCurrentUserWorkflow.xaml

This workflow will receive an array of strings containing the name of the process. The purpose of this
workflow is stop killing other session processes.



**In Arguments**

*process_list - String[] - Array of strings containing the name of the processes to be killed.


**Contact**

Eduardo Romano (eduardo.romano@ge.com)
Carlos Godinez (carlos.godinez@ge.com)


