Last Updated: 2/26/2017

Descriptions:
Convert any SecureString  to a String type at runtime.

Input:
InputSecureString:  SecureString that is input to be unmasked.

Output:
UnsecureStringOutput:  Standard String being created from the SecureString to the workflow.

Notes: 
1.  As with any password nothing should be logged.
2.  Done at runtime to maintain secure assets on Server.