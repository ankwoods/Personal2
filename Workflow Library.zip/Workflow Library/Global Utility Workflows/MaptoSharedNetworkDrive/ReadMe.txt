Last Updated: 8/20/2017

Descriptions:
Map any shared network drive folder and move files from it on local machine.

Input:
AssetName: String , Asset Name for Username and password.
Shared Drive Path:  String, shared network drive path. (for ex : "\\abc\d")
Download Loc : String , Where you want download files from shared drive folder to local.
FolderPath : String , Folder path of network drive .

Output:
NA