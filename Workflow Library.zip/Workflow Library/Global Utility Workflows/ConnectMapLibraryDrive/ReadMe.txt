Last Updated: 2/26/2017

Descriptions:
Map any library folder to a network drive on the local machine.

Input:
Username:  String, username for library folder.
Password:  SecureString, Password for library folder.
LibraryPath:  String, Full web path for the mapped library folder.
DriveLetter:  String, Drive letter folder will be mapped to on the local machine.

Output:
NA

Notes: 
1.  Please see full library instructions on mapping a network drive for paths and prereqs.
2.  If you have any issue check for permissions before contacting the library help desk.