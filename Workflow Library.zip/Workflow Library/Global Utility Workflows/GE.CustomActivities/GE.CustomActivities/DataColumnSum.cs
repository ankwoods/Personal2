﻿using System;
using System.Activities;
using System.Linq;
using System.ComponentModel;
using System.Data;

namespace GE.CustomActivities
{
    public class DataColumnSum : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<DataTable> DataTable { get; set; }

        [Category("Input")]
        public InArgument<String> ColumnName { get; set; }

        [Category("Output")]
        public OutArgument<double> SumResult { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            var datatable = DataTable.Get(context);
            var columnname = ColumnName.Get(context);

            var result = datatable.AsEnumerable().Sum(row => row.Field<Double>(columnname));

            SumResult.Set(context, result);
        }


    }
}

