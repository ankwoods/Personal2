﻿//using System;
//using System.Activities;
//using System.ComponentModel;
//using System.Diagnostics;
//using System.Linq;

//namespace GE.CustomActivities
//{
//    public class KillProcess : CodeActivity
//    {
//        [Category("Input")]
//        [RequiredArgument]
//        public InArgument<string> ProcessName { get; set; }

//        [Category("Input")]
//        public InArgument<string> UserName { get; set; }

//        protected override void Execute(CodeActivityContext context)
//        {
//            string process = ProcessName.Get(context);
//            string username = UserName.Get(context);

//            Process[] list;

//            if (string.IsNullOrEmpty(username))
//                username = Environment.UserName;

//            list = Process.GetProcesses().Where(p => p.StartInfo.EnvironmentVariables["USERNAME"].ToString() == username).ToArray();

//            if (list.Length > 0)
//            {
//                foreach (Process x in list)
//                {
//                    if (x.ProcessName.ToLower().ToString() == process.ToLower())
//                        Process.GetProcessById(x.Id).Kill();
//                }
//            }

//        }
//    }
//}
