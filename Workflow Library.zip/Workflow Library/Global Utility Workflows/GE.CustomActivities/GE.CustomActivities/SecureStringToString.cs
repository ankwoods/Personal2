﻿using System;
using System.Activities;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security;

namespace GE.CustomActivities
{
    public class SecureStringToString : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<SecureString> SecuredString { get; set; }

        [Category("Output")]
        [RequiredArgument]
        public OutArgument<string> Result { get; set; }
        
        protected override void Execute(CodeActivityContext context)
        {
            IntPtr unmanagedString = IntPtr.Zero;
            string result = string.Empty;

            try
            {
                unmanagedString = Marshal.SecureStringToGlobalAllocUnicode(SecuredString.Get(context));
                result = Marshal.PtrToStringUni(unmanagedString);
            }
            finally
            {
                Marshal.ZeroFreeGlobalAllocUnicode(unmanagedString);
            }

            Result.Set(context, result);
        }
    }
}
