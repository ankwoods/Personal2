﻿using System.Activities;
using System.ComponentModel;
using System.Data;

namespace GE.CustomActivities
{
    public class SetTableColumnNames : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<DataTable> Datatable { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string[]> ColumnNames { get; set; }

        [Category("Output")]
        [RequiredArgument]
        public OutArgument<DataTable> Result { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            DataTable table = Datatable.Get(context);
            string[] columnNames = ColumnNames.Get(context);
            int counter = table.Columns.Count;

            for (int i = 0; i < counter; i++) {
                string name = columnNames[i];

                if(!string.IsNullOrEmpty(name))
                    table.Columns[i].ColumnName = name;
            }

            Result.Set(context, table);
        }
    }
}
