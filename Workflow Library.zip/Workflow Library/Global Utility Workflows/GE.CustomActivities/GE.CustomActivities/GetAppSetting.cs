﻿using System;
using System.Configuration;
using System.Activities;
using System.ComponentModel;
using System.Xml;

namespace GE.CustomActivities
{
    public class GetConfigurationKey : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> AppKey { get; set; }

        [Category("Input")]
        public InArgument<string> ConfigFileName{ get; set; }

        [Category("Input")]
        public InArgument<string> TagName { get; set; }

        [Category("Output")]
        [RequiredArgument]
        public OutArgument<string> AppValue { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            string key = AppKey.Get(context);
            string configFile = ConfigFileName.Get(context);
            string tagName = TagName.Get(context);
            string result = string.Empty;

            if (string.IsNullOrEmpty(configFile))
                configFile = "app.config";

            if (string.IsNullOrEmpty(tagName))
                tagName= "add";

            XmlDocument doc = new XmlDocument();
            doc.Load(configFile);
            XmlNodeList list = doc.GetElementsByTagName(tagName);

            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].Attributes["key"].Value == key)
                {
                    result = list[i].Attributes["value"].Value;
                    break;
                }
            }

            AppValue.Set(context, result);
        }
    }
}
