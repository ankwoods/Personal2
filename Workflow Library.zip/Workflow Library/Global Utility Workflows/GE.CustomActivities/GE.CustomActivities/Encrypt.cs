﻿using System;
using System.Activities;
using System.ComponentModel;
using System.Text;
using System.IO;
using System.Security.Cryptography;

namespace GE.CustomActivities
{
    public class EncryptText : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Text { get; set; }

        [Category("Input")]
        public InArgument<string> PassPhrase { get; set; }

        [Category("Output")]
        [RequiredArgument]
        public OutArgument<string> Result { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            string EncryptionKey = "RPA_15_6r34t!";
            string clearText = Text.Get(context);
            string passPhrase = PassPhrase.Get(context);

            if (!string.IsNullOrEmpty(passPhrase))
                EncryptionKey = passPhrase;            

            byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);

            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    clearText = Convert.ToBase64String(ms.ToArray());
                }
            }

            Result.Set(context, clearText);
        }

    }
}
