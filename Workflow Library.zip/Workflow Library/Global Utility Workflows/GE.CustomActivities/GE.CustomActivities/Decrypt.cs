﻿using System;
using System.Activities;
using System.ComponentModel;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace GE.CustomActivities
{
    public class DecryptText : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Text { get; set; }

        [Category("Input")]
        public InArgument<string> PassPhrase { get; set; }

        [Category("Output")]
        [RequiredArgument]
        public OutArgument<string> Result { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            string EncryptionKey = "RPA_15_6r34t!";
            string cipherText = Text.Get(context);
            string passPhrase = PassPhrase.Get(context);

            if (!string.IsNullOrEmpty(passPhrase))
                EncryptionKey = passPhrase;

            cipherText = cipherText.Replace(" ", "+");
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }

            Result.Set(context, cipherText);
        }
    }
}
