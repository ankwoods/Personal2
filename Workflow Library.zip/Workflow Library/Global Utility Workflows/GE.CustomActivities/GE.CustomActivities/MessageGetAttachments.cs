﻿using System.Activities;
using System.ComponentModel;
using System.IO;

namespace GE.CustomActivities
{
    public class MessageGetAttachments : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Path { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> FileType { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> TargetPath { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            string path = Path.Get(context);
            string filetype= FileType.Get(context);
            string targetpath= TargetPath.Get(context);

            using (var msg = new MsgReader.Outlook.Storage.Message(path))
            {
                foreach (object x in msg.Attachments)
                {
                    MsgReader.Outlook.Storage.Attachment att = (MsgReader.Outlook.Storage.Attachment)x;

                    switch (filetype)
                    {
                        case "Excel":
                            if (att.FileName.Contains(".xlsx"))
                                CreateFile(targetpath, att);
                            break;

                        case "PDF":
                            if (att.FileName.Contains(".pdf"))
                                CreateFile(targetpath, att);
                            break;
                    }
                }
            }
        }

        private static void CreateFile(string targetpath, MsgReader.Outlook.Storage.Attachment att)
        {
            using (var fs = new FileStream(targetpath, FileMode.Create, FileAccess.Write))
            {
                fs.Write(att.Data, 0, att.Data.Length);
            }
        }
    }
}
