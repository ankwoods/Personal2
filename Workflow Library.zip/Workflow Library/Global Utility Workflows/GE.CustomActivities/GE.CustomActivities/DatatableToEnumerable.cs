﻿using System.Collections.Generic;
using System.Activities;
using System.ComponentModel;
using System.Data;

namespace GE.CustomActivities
{
    public class DatatableToEnumerable : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<DataTable> Datatable { get; set; }

        [Category("Input")]
        public InArgument<string> OrderBy { get; set; }

        [Category("Input")]
        public InArgument<bool> Descending { get; set; }

        [Category("Output")]
        [RequiredArgument]
        public OutArgument<IEnumerable<DataRow>> Result { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            DataTable table = Datatable.Get(context);
            string orderBy = OrderBy.Get(context);
            bool descending = Descending.Get(context);

            if (table.Rows.Count > 0)
            {

                DataView view = table.DefaultView;

                if (!string.IsNullOrEmpty(orderBy))
                {
                    if (descending)
                        view.Sort = orderBy + " desc";
                    else
                        view.Sort = orderBy;
                }

                Result.Set(context, view.ToTable().AsEnumerable());
            }
        }
    }
}
