﻿using System;
using System.ComponentModel;
using System.Activities;
using UiPath.Excel;
using Microsoft.Office.Interop.Excel;
using System.IO;

namespace GE
{
    public class ImportCSVToExcel : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<WorkbookApplication> Workbook { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Sheet { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> CSVFilename { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> StartCell { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            WorkbookApplication App = Workbook.Get(context);
            string sheetname = Sheet.Get(context);
            string csvfile = CSVFilename.Get(context);
            string startcell = StartCell.Get(context);

            Worksheet sheet = (Worksheet)App.CurrentWorkbook.Worksheets[sheetname];
            ImportCSV(csvfile, sheet, sheet.get_Range(startcell), new int[] { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 }, false);
        }

        private void ImportCSV(string importFileName, Worksheet destinationSheet, Range destinationRange, int[] columnDataTypes, bool autoFitColumns)
        {
            destinationSheet.QueryTables.Add("TEXT;" + Path.GetFullPath(importFileName), destinationRange, Type.Missing);
            destinationSheet.QueryTables[1].Name = Path.GetFileNameWithoutExtension(importFileName);
            destinationSheet.QueryTables[1].FieldNames = true;
            destinationSheet.QueryTables[1].RowNumbers = false;
            destinationSheet.QueryTables[1].FillAdjacentFormulas = false;
            destinationSheet.QueryTables[1].PreserveFormatting = true;
            destinationSheet.QueryTables[1].RefreshOnFileOpen = false;
            destinationSheet.QueryTables[1].RefreshStyle = XlCellInsertionMode.xlOverwriteCells;
            destinationSheet.QueryTables[1].SavePassword = false;
            destinationSheet.QueryTables[1].SaveData = true;
            destinationSheet.QueryTables[1].AdjustColumnWidth = true;
            destinationSheet.QueryTables[1].RefreshPeriod = 0;
            destinationSheet.QueryTables[1].TextFilePromptOnRefresh = false;
            destinationSheet.QueryTables[1].TextFilePlatform = 437;
            destinationSheet.QueryTables[1].TextFileStartRow = 2;
            destinationSheet.QueryTables[1].TextFileParseType = XlTextParsingType.xlDelimited;
            destinationSheet.QueryTables[1].TextFileTextQualifier = XlTextQualifier.xlTextQualifierDoubleQuote;
            destinationSheet.QueryTables[1].TextFileConsecutiveDelimiter = false;
            destinationSheet.QueryTables[1].TextFileTabDelimiter = false;
            destinationSheet.QueryTables[1].TextFileSemicolonDelimiter = false;
            destinationSheet.QueryTables[1].TextFileCommaDelimiter = true;
            destinationSheet.QueryTables[1].TextFileSpaceDelimiter = false;
            destinationSheet.QueryTables[1].TextFileColumnDataTypes = columnDataTypes;

            destinationSheet.QueryTables[1].Refresh(false);

            if (autoFitColumns == true)
                destinationSheet.QueryTables[1].Destination.EntireColumn.AutoFit();
        }
    }
}
