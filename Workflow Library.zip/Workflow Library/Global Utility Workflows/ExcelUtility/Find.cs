﻿using System;
using System.ComponentModel;
using System.Activities;
using UiPath.Excel;
using Microsoft.Office.Interop.Excel;
using System.Reflection;

namespace GE
{
    public class Find : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<WorkbookApplication> Workbook { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Sheet { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<Range> FindRange { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> FindValue { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<Int32> LookAt { get; set; }

        [Category("Input")]
        [DefaultValue("")]
        public InArgument<string> Exceptions { get; set; }

        [Category("Output")]
        [RequiredArgument]
        [DefaultValue("")]
        public OutArgument<string> CellReference { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            WorkbookApplication book = Workbook.Get(context);
            string sheet = Sheet.Get(context);
            string exceptions = Exceptions.Get(context);
            string findvalue = FindValue.Get(context);
            Range findRange = FindRange.Get(context);
            Int32 lookat = LookAt.Get(context);
            Worksheet worksheet = (Worksheet)book.CurrentWorkbook.Worksheets[sheet];

            Range lastFind = null;
            string cellRef = String.Empty;
            string[] dExceptions = exceptions.Split(new char[] { ',' });

            try
            {
                Range webCell = findRange.Find(findvalue, Missing.Value, XlFindLookIn.xlFormulas, lookat, XlSearchOrder.xlByRows,
                    XlSearchDirection.xlNext, false, false, false);

                if (webCell == null && exceptions.Length > 0)
                {
                    double findAmount = 0;
                    foreach (string exception in dExceptions)
                    {
                        findAmount = Convert.ToDouble(findvalue) - Convert.ToDouble(exception);
                        webCell = findRange.Find(findAmount, Missing.Value, XlFindLookIn.xlFormulas,
                            LookAt, XlSearchOrder.xlByRows, XlSearchDirection.xlNext, false, false, false);

                        if (webCell != null) break;
                    }
                }

                while (webCell != null)
                {
                    if (lastFind == null)
                        lastFind = webCell;
                    else if (webCell.get_Address(XlReferenceStyle.xlA1) == lastFind.get_Address(XlReferenceStyle.xlA1))
                        break;
                    webCell = findRange.FindNext(webCell);
                }

                if (webCell != null)
                    cellRef = webCell.get_Address(XlReferenceStyle.xlR1C1);
            }
            catch (Exception)
            {
                cellRef = string.Empty;
            }

            CellReference.Set(context, cellRef);
        }
    }
}
