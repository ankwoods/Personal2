﻿using System.ComponentModel;
using System.Activities;
using Microsoft.Office.Interop.Excel;

namespace GE
{
    public class GetCellReference : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<Range> Range { get; set; }

        [Category("Output")]
        [RequiredArgument]
        public OutArgument<string> CellReference { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            Range range = Range.Get(context);
            CellReference.Set(context, range.get_Address(XlReferenceStyle.xlR1C1));
        }
    }
}
