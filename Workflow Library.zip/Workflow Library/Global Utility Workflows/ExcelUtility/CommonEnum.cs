﻿namespace GE.Excel
{
    public enum XlHAlign
    {
        xlHAlignRight = -4152,
        xlHAlignLeft = -4131,
        xlHAlignJustify = -4130,
        xlHAlignDistributed = -4117,
        xlHAlignCenter = -4108,
        xlHAlignGeneral = 1,
        xlHAlignFill = 5,
        xlHAlignCenterAcrossSelection = 7
    }

    public enum XlLookAt
    {
        xlWhole = 1,
        xlPart = 2
    }
}