﻿using System;
using System.ComponentModel;
using System.Activities;
using UiPath.Excel;
using Microsoft.Office.Interop.Excel;

namespace GE
{
    public class ApplyFilterDates : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<WorkbookApplication> Workbook { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Sheet { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Range { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<Int32> FilterColumn { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Date1 { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Date2 { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            WorkbookApplication App = Workbook.Get(context);
            string sheetname = Sheet.Get(context);
            string range = Range.Get(context);
            string date1 = Date1.Get(context);
            string date2 = Date2.Get(context);
            Int32 filtercolumn = FilterColumn.Get(context);
            Worksheet sheet = (Worksheet)App.CurrentWorkbook.Worksheets[sheetname];
            sheet.Range[range].AutoFilter(filtercolumn, date1, XlAutoFilterOperator.xlAnd, date2, true);
        }
    }
}
