﻿using System.ComponentModel;
using System.Activities;
using UiPath.Excel;

namespace GE
{
    public class SaveWorkbook : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<WorkbookApplication> Workbook { get; set; }


        protected override void Execute(CodeActivityContext context)
        {
            WorkbookApplication App = Workbook.Get(context);
            App.CurrentWorkbook.Save();
         }
    }
}
