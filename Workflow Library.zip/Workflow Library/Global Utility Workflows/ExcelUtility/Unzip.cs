﻿using System.ComponentModel;
using System.Activities;
using System.IO.Compression;

namespace GE.Utility
{
    public class ExtractZipToDirectory : CodeActivity
    {

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> SoruceZipFilename { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> ExtractPath { get; set; }

        [Category("Output")]
        [RequiredArgument]
        public OutArgument<bool> Result { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            try
            {
                string sourcePath = SoruceZipFilename.Get(context);
                string extractLocation = ExtractPath.Get(context);
                ZipFile.ExtractToDirectory(sourcePath, extractLocation);
                Result.Set(context, true);
            }
            catch
            {
                Result.Set(context, false);
            }
        }
    }
}
