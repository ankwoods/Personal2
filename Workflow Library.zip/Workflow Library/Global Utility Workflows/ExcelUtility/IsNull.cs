﻿using System.ComponentModel;
using System.Activities;

namespace GE
{
    public class IsNull : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<object> Object { get; set; }

        [Category("Output")]
        [RequiredArgument]
        public OutArgument<bool> Result { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            bool result = false;
            object obj = Object.Get(context);
            if (obj == null) result = true;
            Result.Set(context, result);
        }
    }
}