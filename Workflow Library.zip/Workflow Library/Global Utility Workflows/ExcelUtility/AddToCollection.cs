﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using System.Activities;
using System.Collections.Specialized;
using UiPath.Excel;

namespace GE
{
    public class AddToCollection : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<NameValueCollection> Collection { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Name { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Value { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            NameValueCollection collection = Collection.Get(context);
            string name = Name.Get(context);
            string value = Value.Get(context);
            collection.Add(name, value);
        }
    }
}
