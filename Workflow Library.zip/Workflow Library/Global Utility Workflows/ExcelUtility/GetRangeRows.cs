﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Activities;
using Microsoft.Office.Interop.Excel;

namespace GE
{
    public class GetRangeRows : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<Range> Range { get; set; }

        [Category("Output")]
        [RequiredArgument]
        public OutArgument<List<Range>> Collection { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            Range range = Range.Get(context);
            List<Range> collection = new List<Range>();
            foreach (Range row in range.Rows)
                collection.Add(row);
            Collection.Set(context, collection);
        }
    }
}
