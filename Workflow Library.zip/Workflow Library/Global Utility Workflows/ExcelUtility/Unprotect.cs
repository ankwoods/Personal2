﻿using System.ComponentModel;
using System.Activities;
using UiPath.Excel;
using Microsoft.Office.Interop.Excel;

namespace GE
{
    public class Unprotect : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<WorkbookApplication> Workbook { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Sheet { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            WorkbookApplication book = Workbook.Get(context);
            string sheet = Sheet.Get(context);
            Worksheet worksheet = (Worksheet)book.CurrentWorkbook.Worksheets[sheet];
            worksheet.Unprotect();
        }
    }
}
