﻿using System;
using System.ComponentModel;
using System.Activities;
using UiPath.Excel;
using Microsoft.Office.Interop.Excel;
using System.Reflection;
using GE.Excel;

namespace GE
{
    public class SearchValue : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<WorkbookApplication> Workbook { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Sheet { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> FindRange { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> FindValue { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<GE.Excel.XlLookAt> LookAt { get; set; }

        [Category("Output")]
        [RequiredArgument]
        [DefaultValue("")]
        public OutArgument<string> CellReference { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            WorkbookApplication book = Workbook.Get(context);
            string sheet = Sheet.Get(context);
            string findvalue = FindValue.Get(context);
            string findRange = FindRange.Get(context);
            GE.Excel.XlLookAt lookat = LookAt.Get(context);
            Worksheet worksheet = (Worksheet)book.CurrentWorkbook.Worksheets[sheet];
            string cellRef = String.Empty;
  
            try
            {
                Range webCell = worksheet.Range[findRange].Find(findvalue, Missing.Value, XlFindLookIn.xlValues, lookat, XlSearchOrder.xlByRows,
                    XlSearchDirection.xlNext, false, false, false);
              
                if (webCell != null)
                    cellRef = webCell.get_Address(XlReferenceStyle.xlR1C1);
            }
            catch (Exception)
            {
                cellRef = string.Empty;
            }

            CellReference.Set(context, cellRef);
        }
    }
}
