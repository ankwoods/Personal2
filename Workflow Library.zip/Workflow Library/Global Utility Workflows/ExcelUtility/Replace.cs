﻿using System.ComponentModel;
using System.Activities;
using UiPath.Excel;
using Microsoft.Office.Interop.Excel;
using System.Reflection;

namespace GE
{
    public class Replace : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<WorkbookApplication> Workbook { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Sheet { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> SearchRange { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Find { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> ReplaceWith { get; set; }
        
        protected override void Execute(CodeActivityContext context)
        {
            WorkbookApplication App = Workbook.Get(context);
            string sheetname = Sheet.Get(context);
            string range = SearchRange.Get(context);
            string find = Find.Get(context);
            string replace = ReplaceWith.Get(context);
            Worksheet sheet = (Worksheet)App.CurrentWorkbook.Worksheets[sheetname];
            Range cell = sheet.Range[range].Cells.Find(find, Missing.Value, XlFindLookIn.xlFormulas, XlLookAt.xlWhole, XlSearchOrder.xlByRows, XlSearchDirection.xlNext, false, false, false);
            if(cell != null)
                sheet.Range[range].Cells.Replace(find, replace, XlLookAt.xlWhole, XlSearchOrder.xlByRows, false, true, false);
        }
    }
}
