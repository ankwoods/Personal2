﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using System.Activities;
using System.Collections.Specialized;
using UiPath.Excel;
using Microsoft.Office.Interop.Excel;
using GE.Excel;

namespace GE
{
    public class GetRowCellData : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<Range> Range { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<Int32> CellIndex{ get; set; }

        [Category("Output")]
        [RequiredArgument]
        public OutArgument<string> Result { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            Range range = Range.Get(context);
            Int32 index = CellIndex.Get(context);
            string result = String.Empty;

            var output = range.Cells[index].Value2;
            if (output != null)
                result = Convert.ToString(output);

            Result.Set(context, result);
        }
    }
}
