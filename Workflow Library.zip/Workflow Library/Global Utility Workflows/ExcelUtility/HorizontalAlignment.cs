﻿using System.ComponentModel;
using System.Activities;
using UiPath.Excel;
using Microsoft.Office.Interop.Excel;
using Local = GE.Excel;

namespace GE
{
    public class HorizontalAlignment : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<WorkbookApplication> Workbook { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Sheet { get; set; }

        [Category("Input")]
        public InArgument<string> Range { get; set; }

        [Category("Input")]
        public InArgument<Local.XlHAlign> RangeAlignment { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            WorkbookApplication App = Workbook.Get(context);
            string sheetname = Sheet.Get(context);
            string range = Range.Get(context);
            Local.XlHAlign align = RangeAlignment.Get(context);

            Worksheet sheet = (Worksheet)App.CurrentWorkbook.Worksheets[sheetname];
            sheet.Range[range].Cells.HorizontalAlignment = align;
        }
    }
}