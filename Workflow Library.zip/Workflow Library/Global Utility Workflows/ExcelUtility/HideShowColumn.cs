﻿using System.ComponentModel;
using System.Activities;
using UiPath.Excel;
using Microsoft.Office.Interop.Excel;
using System.Reflection;

namespace GE
{
    public class HideShowColumn : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<WorkbookApplication> Workbook { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Sheet { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Range { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<bool> Value { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            WorkbookApplication App = Workbook.Get(context);
            string sheetname = Sheet.Get(context);
            string range = Range.Get(context);
            bool value = Value.Get(context);

            Worksheet sheet = (Worksheet)App.CurrentWorkbook.Worksheets[sheetname];
            sheet.get_Range(range, Missing.Value).EntireColumn.Hidden = value;
         }
    }
}
