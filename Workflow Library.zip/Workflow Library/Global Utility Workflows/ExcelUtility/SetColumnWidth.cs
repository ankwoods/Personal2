﻿using System;
using System.ComponentModel;
using System.Activities;
using UiPath.Excel;
using Microsoft.Office.Interop.Excel;
using System.Reflection;

namespace GE
{
    public class SetColumnWidth : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<WorkbookApplication> Workbook { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Sheet { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> ReferenceCell { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<Int32> Width { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            WorkbookApplication App = Workbook.Get(context);
            string sheetname = Sheet.Get(context);
            string startCell = ReferenceCell.Get(context);
            Int32 width = Width.Get(context);
 
            Worksheet sheet = (Worksheet)App.CurrentWorkbook.Worksheets[sheetname];
            sheet.get_Range(startCell, Missing.Value).ColumnWidth = width;
        }
    }
}