﻿using System;
using System.ComponentModel;
using System.Activities;
using UiPath.Excel;
using Microsoft.Office.Interop.Excel;
using System.Reflection;

namespace GE
{
    public class CountNonBlankRows : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<WorkbookApplication> Workbook { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Sheet { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Formula { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> ExecuteOnCell { get; set; }

        [Category("Output")]
        [RequiredArgument]
        public OutArgument<Double> Result { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            WorkbookApplication book = Workbook.Get(context);
            string sheet = Sheet.Get(context);
            string executeon = ExecuteOnCell.Get(context);
            string formula = Formula.Get(context);
            Worksheet worksheet = (Worksheet)book.CurrentWorkbook.Worksheets[sheet];
            worksheet.Cells.Range[executeon, Missing.Value].Formula = formula;
            worksheet.Cells.Calculate();
            Result.Set(context, worksheet.Cells.Range[executeon, Missing.Value].Value2);
        }
    }
}
