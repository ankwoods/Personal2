Last Updated: 2/26/2017

Descriptions:
Clear queue items that are set to status of NEW.

Input:
QueueName:  String of the Queue Name in UiPath.
TransactionSuccessful:  Boolean If you want the transactions to be cleared as Successful or as Failed.

Output:
NA

Notes: 
1.  Should be used for testing to keep queue clear.
2.  Feature should be added to future UiPath versions to no longer need this workflow.