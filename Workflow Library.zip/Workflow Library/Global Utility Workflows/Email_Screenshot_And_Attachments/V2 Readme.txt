Email_Screenshot_and_Attachments_V2.xaml

This is an improved version of Email_Screenshot_and_Attachments that is much more configurable, and can send an
email with or without a screenshot, with/without debug or error information, and with/without an attachment. You
can use this to just send a simple email without any attachments as well, and most of the arguments are optional


**In Arguments**

* ProcessName: String - default "Robot"
	-- Used as the prefix in the name of the error screenshot
	
* SubjectText: String - default ""
	-- Subject of the email
	
* BodyText: String - default ""
	-- Body of the email
	
* EmailTo: String (Required unless EmailToAsset is set)
	-- An email or list of emails to send to. If a list, separate by semicolons.

* EmailToAsset: String (Required unless EmailTo is set)
	-- Name of an Orchestrator asset containing an email/list of emails to send to.
	
* AttachmentPath: String - default Nothing
	-- Full file path of an attachment for the email

* EmailCredentialName: String - default "RPA_EMAIL"
	-- Name of an Orchestrator credential containing the login information of the email to send with.
		Defaults to the standard RPA Dev/Prod email account, which is sufficient for most uses.
		
* TakeScreenshot: Boolean - default False
	-- If True, will take a screenshot of the desktop and send with the email. Screenshot is saved in BaseFilePath.
	
* PrintDebugInformation: Boolean - default False
	-- if True, will append the current timestamp and server name to the end of the body.
	
* PrintException: Exception - default Nothing
	-- If not Nothing, will append the specified exception name and stack trace to the end of the body.
	
* BaseFilePath: String - default Windows Temp directory (i.e. %TEMP%)
	-- If TakeScreenshot is True, the screenshot will be stored in this directory.
	
**In/Out Arguments**

N/A

**Out Arguments**

* Success: Boolean
	-- True if the email was sent successfully, False otherwise.

**Starting UI state**

N/A

**Ending UI state**

N/A

**Required Applications**

N/A

**Contact**

Brandon Dadosky (brandon.dadosky@ge.com)

