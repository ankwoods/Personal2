Last Updated: 2/13/2017

V1 file uses SMTP mail message activity instead of Outlook. You must pass a credential asset
name containing the email credentials you want to use.

Guidelines:

Workflow contains a method to take a screenshot and send out to  
specified distribution list. 

Note: 
1. Specifying "E2k" account as "from" attribute will result in process  
failure. Personal "E2k" accounts should be specified as default and the  
"from" field should be left blank. 

2. Process allows 1 attachment by default, for additional attachments  
user must add arguments for additional attachments into the process. 

3. For questions, please contact Trevor Napier(212571413) or Stan  
Chulsky(212443046).
