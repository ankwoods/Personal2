Last Updated: 2/26/2017

Descriptions:
Disconnect any mapped drive via the drive letter.

Input:
DrivePath: String of the drive letter to be disconnected. (Ex "Z" for Z:\)

Output:
NA

Notes: 
NA