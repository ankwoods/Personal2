Create_Zip_File.xaml

The purpose of this workflow is to create a zip file for the list of files in a particular folder.

In Arguments
1. ZipFilePath - String - Need to pass the complete path where the Zip File needs to be created with the name. Example "C:\User\<Login Account>\<FileName.zip>"
2. FilePathToZip - String - Need to pass the complete path of the folder which contains the files that need to be zip. "Example C:\User\<Login Account>\ExtractedFile"

Out Arguments
1. BlnZipCreated - Boolean - This will return true/false based on whether zip file was created successfully or not.

Reference
This code was downloaded from Internet and modified to make it dynamic by passing the above mentioned "In Arguments".
